
public class Record{
	
	def id
	def date
	def target
	def operation
	def status
	def reports
}

public class Report{
	def resource
	def location
	def xml
}

def DB_RECORDS = '''
<db>
	<data>
		<id>01</id>
		<date>01-01-2013--00-00-AM</date>
		<target>vm-01</target>
		<operation>extract</operation>
		<status>success</status>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>
	<data>
		<id>02</id>
		<date>01-02-2013--00-00-AM</date>
		<target>vm-01</target>
		<status>success</status>
		<operation>extract</operation>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>
	<data>
		<id>03</id>
		<date>01-03-2013--00-00-AM</date>
		<target>vm-02</target>
		<operation>extract</operation>
		<status>success</status>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>
	<data>
		<id>04</id>
		<date>01-04-2013--00-00-AM</date>
		<target>vm-04</target>
		<operation>commit</operation>
		<status>fail</status>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>

</db>
  '''


def records = new XmlSlurper().parseText(DB_RECORDS)
def allRecords = records.data.list()
ArrayList dataArray = []


 allRecords.collect(){ currentRecord ->
		ArrayList reports = []
		currentRecord.reports.each(){ currentReport ->
			reports.add ( new Report(resource:currentReport.resource.toString(), location:currentReport.location.toString(), xml:currentReport.xml.toString())
				)
		}
	 
	   dataArray.add(  new Record(id:currentRecord.id.toString() , 
		   target:currentRecord.target.text() , 
		   date:currentRecord.date.text() ,
		   operation:currentRecord.operation.text() ,
		   status:currentRecord.date.toBoolean() ,
		   reports:reports,
		  
		   
		   ))   
		
	}

def builder = new groovy.json.JsonBuilder()

def root = builder {
      "DB" (
        dataArray.each ({ record->
            "Id" record.id
            "Target" record.target
			"Date" record.date
			"Operation" record.operation
			"Status" record.status
			
        })
    )
}

println builder.toPrettyString() 