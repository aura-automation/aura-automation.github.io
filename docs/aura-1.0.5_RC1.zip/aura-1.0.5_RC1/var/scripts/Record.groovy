public class Record{
	
	def id
	def date
	def target
}