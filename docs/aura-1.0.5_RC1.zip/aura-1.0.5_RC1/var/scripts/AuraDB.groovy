import org.apache.commons.configuration.*

import org.apache.commons.lang.SystemUtils
import groovy.xml.StreamingMarkupBuilder
import java.text.SimpleDateFormat

import groovy.json.JsonBuilder

public class AuraDB{

	def auraHome = null
	def auraRepo = null
	def userHome = null
	def user = null
	
	def antEnvName = null
	def noPrompt = null
	def currentDir = null
	def ant = null
	

	void update(status){
		
		def db = new File(auraRepo + File.separator + "db.xml")
		def root
		if (db.exists()){ 
			root = new XmlSlurper().parseText(db.getText())
		}else{
			def input = '''
<db>

</db>
'''
			root = new XmlSlurper().parseText(input)
		}
		
		root.appendNode {
				identifier("id")
				label(label)
				items {
					id("id")
					date("date")
					target("target")
					operation("target")
						reports {
							resource("")
							location("loc")
						}
						reports {
							resource("")
							location("loc")
						}
				}
			}
		
		def builder = new StreamingMarkupBuilder()
		def writer = new FileWriter(db )
		writer << builder.bind {
			mkp.yield root
		}
	}
	
	void read(){
		
		 def DB_RECORDS = '''
<db>
	<data>
		<id>01</id>
		<date>01-01-2013--00-00-AM</date>
		<target>vm-01</target>
		<operation>extract</operation>
		<status>success</status>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>
	<data>
		<id>02</id>
		<date>01-02-2013--00-00-AM</date>
		<target>vm-01</target>
		<status>success</status>
		<operation>extract</operation>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>
	<data>
		<id>03</id>
		<date>01-03-2013--00-00-AM</date>
		<target>vm-02</target>
		<operation>extract</operation>
		<status>success</status>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>
	<data>
		<id>04</id>
		<date>01-04-2013--00-00-AM</date>
		<target>vm-04</target>
		<operation>commit</operation>
		<status>fail</status>
		<reports>
			<resource>JVM</resource>
			<location>JVM-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
		<reports>
			<resource>DataSource</resource>
			<location>DataSource-Resource.html</location>
			<xml>JVM-Resource.xml</xml>
		</reports>
	</data>

</db>
  '''
	println "reading	" 
	  def dbFile = new File("/home/jatin/.aura_repo/db-1.xml")	 
	  def records = new XmlSlurper().parseText(dbFile.getText())
	  def allRecords = records.data

	  def fromDate = '01-01-2012'
	  def toDate 
	  def server 
	  
	  allRecords = fromDate ? allRecords.findAll{new SimpleDateFormat("dd-MM-yyyy--hh-mm-aa").parse(it.date.toString()).after(new SimpleDateFormat("dd-MM-yyyy--mm-hh-aa").parse(fromDate + "--00-00-AM"))}: allRecords
	  allRecords = toDate ? allRecords.findAll{new SimpleDateFormat("dd-MM-yyyy--hh-mm-aa").parse(it.date.toString()).before(new SimpleDateFormat("dd-MM-yyyy--mm-hh-aa").parse(toDate + "--00-00-AM"))}: allRecords
	  allRecords = server ? allRecords.findAll{it.target.text().equals(server)}:allRecords
	  
	  java.util.List<Record> listOfRecords = []
	  
	  allRecords.each{ record ->
		  Record newRecord = new Record()
		  newRecord.id = record.id
		  newRecord.target= record.target
		  
		  listOfRecords.add(newRecord )
		  }
	  
	  assert allRecords.list() instanceof java.util.List
	  
		def tasks = [[1, "ab"], [2, "cd"], [3, "ef"]]
		assert tasks instanceof java.util.List
		
		def data = [
		  success: true,
		  count: tasks.size(),
		  data: tasks.each {[ 1: 1]}
		]
		
		def json = new JsonBuilder(data)
		println json.toPrettyString()
		
		

/*	  def json = new JsonBuilder()
		db{
			"data" (
				allRecords.each{ record -> 
				"id" record.id,
				"date" 	record.date
				}
			)
		}

	 
	  println "json " + json.toPrettyString()
	   
*/	 // def prettyJson = JsonOutput.prettyPrint(json.toString())
	 // println(prettyJson)
	}
	void initProperties(){
		auraHome = ant.project.properties.'AURA_HOME'
		auraRepo = ant.project.properties.'AURA_REPO'
		antEnvName = ant.project.properties.'env.name'
		currentDir = ant.project.properties.'CURRENT_DIR'
		noPrompt = ant.project.properties.'noprompt'
		user = ant.project.properties.'USER'
		userHome = ant.project.properties.'USER_HOME'
	
	}
	
	
	void setAntBuilder(antBuilder) {
		ant = new AntBuilder(antBuilder.project)
		antBuilder.project.copyInheritedProperties(ant.project)
		antBuilder.project.copyUserProperties(ant.project)
		
		initProperties()
	}
}
